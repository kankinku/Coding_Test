import sys

def input():
    return sys.stdin.readline().strip()

def check(x):
    for i in range(2, int(x**0.5) + 1):
        if x % i == 0:
            return False 
    return True

N = int(input())
for _ in range(N):
    num = int(input())
    while True:
        if num == 0 or num == 1:
            print(2)
            break
        if check(num):
            print(num)
            break
        else:
            num += 1
