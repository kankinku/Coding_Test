A,B = map(int,input().split())
a,b = A,B
# A가 최대 공약수
while b != 0: 
    a,b = b, a%b
print(a,b)
print(int(A*B/a))