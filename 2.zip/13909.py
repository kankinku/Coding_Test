import sys
def input():
    return sys.stdin.readline().strip()

# 0 은 닫혀있는 상태 1 은 열려있는 상태
N = int(input())
window = [0] * N
window[0] = 0

# 자신의 번호 이전의 창문의 상태는 고정된다.
for i in range(1,N):
    for j in range(i, N, i):
        if window[j] == 1:
            window[j] = 0
        else:
            window[j] = 1

print(window.count(1))