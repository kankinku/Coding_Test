from functools import reduce
import math

N = int(input())
gap =[]
for i in range(N):
    tree = int(input())
    if i != 0: 
        gap.append(tree-back_tree)
    else:
        first = tree
    back_tree = tree

count = reduce(math.gcd,gap)
print(int((tree-first)//count-(N-1)))