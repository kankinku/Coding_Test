S1,M1 = map(int,input().split())
S2,M2 = map(int,input().split())

S1 *= M2
S2 *= M1
M1 *= M2

total_S = S1 + S2
total_M = M1

while total_M != 0: 
    total_S, total_M = total_M, total_S%total_M

print(int((S1+S2)/total_S), int(M1/total_S))