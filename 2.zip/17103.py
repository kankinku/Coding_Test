import sys
def input():
    return sys.stdin.readline().strip()

arr = [0] * 1000001
prime = []
arr[1] = 1
arr[0] = 1

# 소수를 구하는 함수.
for i in range(2, 1000001):
    if arr[i] == 0:
        prime.append(i)
        for j in range(2*i, 1000001, i):
            arr[j] = 1

T = int(input())

for _ in range(T):
    count = 0
    N = int(input())
    for i in prime:
        if i >= N:
            break
        if not arr[N - i] and i <= N-i: 
            count += 1
    print(count)