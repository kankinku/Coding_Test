import sys

def input():
    return sys.stdin.readline().strip()

def check(x):
    for i in range(2, int(x**0.5) + 1):
        if x % i == 0:
            return False 
    return True

check_list = [0,0]

for i in range(2,123456*2+1):
    if check(i):
        check_list.append(1)
    else:
        check_list.append(0)


while True:
    num = int(input())
    count = 0
    if num == 0:
        break
    else:
        for i in range(num+1, 2*num+1):
            if check_list[i] == 1:
                count+=1
        print(count)